import time
import subprocess
import psutil
import subprocess


for i in range (1,10):
    file1 = open("go.txt","w")
    file1.write("0")
    file1.close()
    ppp="sudo kill -9 $(ps -elf|pgrep nr-ue)"
    p = subprocess.Popen(ppp,
                     shell=True,
                     stdout=subprocess.PIPE, 
                     stderr=subprocess.PIPE)
    p.kill()
    processus=subprocess.Popen(['python3', 'UEs_iperf3.py', i*5,300])
    a="0"
    while a=="0":
        try:
            file1 = open("go.txt","r+")
            a=file1.read()
            file1.close()
        except:
            a="0"
        if a=="1":
            processus.kill()
            print("process terminated a=='1'") 
        if round(psutil.virtual_memory()[4]/psutil.virtual_memory()[0]* 100, 2)<6:
            processus.kill()
            print(" memory problem")
            a="1"
        time.sleep(3)
    time.sleep(60)